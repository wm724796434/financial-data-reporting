---
name: structured-repo-query
description: "Query codebases that have their own structured documentation index with a defined query protocol — read the index first, then summaries, only then deep-dive. Prevents skipping-surface mistakes."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [codebase-query, documentation, index, AGENTS.md, CLAUDE.md, knowledge-base, code-review, investigation]
    related_skills: [codebase-inspection, systematic-debugging]
---

# Structured Repository Query

## When to Use

Use this skill whenever you're working in a project that has its **own structured documentation and a defined query protocol**. Signals to look for:

- `AGENTS.md` or `CLAUDE.md` in the project root that defines a query process
- A `综合/` (comprehensive) directory with index files like `功能模块映射.md`, `源码清单.md`
- A `实体/` (entity/summary) directory with per-module summaries
- A `源码解析/` (source analysis) directory with annotated source code
- Any project that says "read X before Y" or "use this file for function-to-file mapping"

**Do NOT use for** raw codebases with no documentation structure — use `codebase-inspection` or direct `search_files` instead.

## Core Protocol

### Rule 1: Index First, Search Last

```
AGENTS.md/CLAUDE.md query protocol
        │
        ▼
  Index files (综合/功能模块映射.md, 源码清单.md)
        │
        ▼
  Entity summaries (实体/)
        │
        ▼
  Sampling verification (源码解析/ header blocks)
        │
        ▼
  Full deep-dive (only when user asks for details)
```

**NEVER** jump straight to `search_files` / `grep` / glob scanning when index files exist. The index was built precisely to answer the question you're about to ask — it's faster, more complete, and prevents skipped-module mistakes.

### Rule 2: Read the Protocol Before Touching Tools

When you see AGENTS.md with a "查询流程" (query flow) section, read the **entire** flow definition before making any tool calls. Common patterns:

- **场景A**: User asks "how does feature X work" → read 功能模块映射.md for file list, then 实体/ for summaries, then 抽样验证 (sample verify) from 源码解析/
- **场景B**: User asks "what files are in directory Y" → read 源码清单.md
- **场景C**: Cross-module dependency tracing → read 实体/ for dependency sections
- **场景D**: Index links broken → fallback to 功能模块映射.md or 源码清单.md
- **场景E**: User asks "what is file X" → read 实体/ summary, or 源码解析/ header block

### Rule 3: Never Make Absolute Absence Claims from a Single Search

If you search for files matching "memory" and find nothing, **do not** say "this project has no memory module." You might have:

- Used the wrong search terms (directory named `memdir/`, not `memory/`)
- Missed the index file that explicitly lists the module (功能模块映射.md lists "记忆系统")
- Hit a tool limitation (search_files with certain patterns can return false negatives)

**Always check the project's own index first.** If the index lists a functional area you didn't find via search, trust the index and investigate.

### Rule 4: Cross-Validate Summaries Against Source

Entity/summary files are **second-hand** — they can be stale or wrong. Before citing them in an answer:

1. Pick 1-3 of the most critical files from the entity's file list
2. Read the **header comment block** (first 50-100 lines) of the corresponding source in 源码解析/
3. If entity and source disagree, trust the source and note the discrepancy

### Rule 5: Follow the File Scope Rules

Many structured documentation projects have "禁止行为" (forbidden actions). Check for these:

- **No modification of the source directory** (e.g., `ClaudeCode-main/` is read-only)
- **No full-file reads for overview questions** — use entity summaries; only read full source when user asks for implementation details
- **No glob scanning** if a module mapping file exists
- **No skipping update steps** after analysis (解析初始化文件.md, 源码清单.md, 实体/ must all be updated)

## Pitfalls

### 1. "It's small, I don't need the index" fallacy
Even a simple question ("does project X have Y?") benefits from the index. The index tells you Y's correct name, location, and all files involved — which ad-hoc search won't.

### 2. Using English search terms in Chinese-documented projects
The documentation might use Chinese terms (记忆系统, 功能模块映射) while source files use English names. Always scan the table of contents before searching.

### 3. Trusting a single search_files call
`search_files` has limitations: path resolution, regex edge cases, file_glob filtering. A zero-result doesn't mean "doesn't exist" — it means "try searching differently or check the index."

### 4. Skipping 抽样验证 (sampling verification)
Entity summaries can be out of date or overly simplified. Always read the header block of at least one core source file to ground your answer.

### 5. Jumping to general-purpose tools
When the project provides specific tools (功能模块映射.md, 源码清单.md), they are almost always more reliable than grep/search_files for structural questions. The index was written by someone who already mapped the dependencies.

## Quick Reference

| Scenario | Step 1 | Step 2 | Step 3 |
|----------|--------|--------|--------|
| "How does feature X work?" | 功能模块映射.md | 实体/ summaries | 抽样验证 from 源码解析/ |
| "What files in directory Y?" | 源码清单.md | — | — |
| "What does file X do?" | 实体/ summary | 源码解析/ header | (optional) full source |
| "Cross-module dependencies?" | 功能模块映射.md + 实体/ | — | — |
| "Is feature X present?" | 功能模块映射.md | — | — |

## Reference Files

- `references/claude-code-memory-system.md` — Concrete worked example showing what happens when you skip the protocol vs follow it, with the full Claude Code memory system architecture revealed by proper querying.

## Verification

Before answering, check:

- [ ] Did I read the AGENTS.md query protocol first?
- [ ] Did I check 功能模块映射.md (or equivalent index) before searching?
- [ ] Did I use 实体/ summaries for overview questions?
- [ ] Did I sample-verify at least one source file header?
- [ ] Is my claim ("doesn't have X") verified against the index, not just search?
- [ ] Did I avoid modifying protected directories (ClaudeCode-main/ etc.)?
