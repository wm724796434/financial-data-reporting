---
name: batch-source-code-analysis
description: 批量分析源码目录中的源文件，提取元数据并生成结构化实体文档。专为数据库存储过程/SQL/Shell脚本等 ETL 类代码设计，特别处理中文注释编码问题。
category: software-development
---

# Batch Source Code Analysis — 批量源码分析与实体文档生成

## 触发条件

遇到以下情况时加载本技能：
- 用户要求"解析"或"分析"某个目录下的源码文件
- 用户要求创建"实体"目录来存放源码分析结论
- 用户要求为一批 Oracle PL/SQL、SQL、Shell 脚本生成结构化文档
- 需要从一个代码目录批量提取每个文件的功能、依赖、输出表等元信息

## 工作流程

### 阶段一：项目解剖（探索结构）

1. **先建立全貌**：用 `search_files(target='files')` 获取所有文件清单，按目录分组
2. **读项目约定文件**：如果存在 `AGENTS.md` 或 `CLAUDE.md`，先读，了解项目对"实体"目录的定义
3. **抽样读典型文件**：从不同子目录各读 1-3 个文件的头部（前 60 行），了解文件格式、注释模式、编码

### 阶段二：建立表名映射（监管集市表关联时必需）

1. **解析表清单建立物理表名→中文名映射**：
   ```python
   import re, json
   with open('监管集市表清单.md', 'r', encoding='utf-8') as f:
       content = f.read()
   table_map = {}
   for line in content.split('\n'):
       m = re.match(r'\|\s*\d+\s*\|\s*监管集市\s*\|\s*(\w+)\s*\|\s*([^|]+)\s*\|', line)
       if m:
           table_map[m.group(1)] = m.group(2).strip()
   json.dump(table_map, open('/tmp/table_map.json', 'w', ensure_ascii=False))
   ```

2. **从源码中提取表引用**：
   ```bash
   iconv -f GBK -t UTF-8 file.prc | grep -oP 'SMTMODS\.\w+' | sort -u
   ```
   或统一提取所有 PBOCD 接口表：
   ```bash
   grep -oP 'PBOCD_\w+' file.prc | sort -u
   ```

### 阶段三：脚本批量处理（推荐方案，替换阶段三/四）

当所有文件的处理逻辑一致时，**优先编写一个 Python 脚本用 execute_code 批量处理**，而不是逐个文件 read_file。这比 delegate_task 子任务模式更快（单次上下文，无子任务开销）。

**脚本模板**在 `templates/batch-enrich.py`，包含完整流程：

```
读取源码 → 解析注释 → 提取表引用 → 查监管集市表中名 → 构建增强注释 → 写回源码 → 同步更新实体文档
```

脚本需要处理的核心逻辑：

1. **构建增强头部注释**（.prc 文件）：
   ```
   程序名 + 业务域 + 用途 + 输出接口表 + 参数 + 引用的SMTMODS表（含中文名） + 修改历史
   ```

2. **实体文档更新**（保留已有内容，新增依赖关系表格）：
   - 用正则提取并保留已有的 `功能概述`、`关键逻辑`、`修改历史` 段落
   - 替换/新增 `依赖关系（监管集市表）` 段落
   - 保留已有 `用途说明` 中的详细版本（优先于源码注释的简略版本）

   关键保留正则：
   ```python
   func_match = re.search(r'## 功能概述\n(.*?)(?=\n## )', existing, re.DOTALL)
   logic_match = re.search(r'## 关键逻辑\n(.*?)(?=\n## |$)', existing, re.DOTALL)
   history_match = re.search(r'## 修改历史\n(.*?)(?=\n## |$)', existing, re.DOTALL)
   ```

3. **.sql 文件处理差异**：
   - `.sql` 文件没有 `CREATE OR REPLACE PROCEDURE` 头部，也没有标准注释块
   - 处理方式：在文件顶部**新增**注释块（而不是替换），包含文件名、业务域、用途、引用的SMTMODS表
   - 实体文档同步方式与 .prc 相同，但元信息不含"存储过程名"而改为"文件类型: SQL脚本"

### 编码处理（关键！复用阶段二内容）

1. **读取**：Oracle PL/SQL 文件的中文注释通常为 GBK/GB18030 编码
   ```python
   def read_gbk(path):
       with open(path, "rb") as f:
           raw = f.read()
       try: return raw.decode("gbk")
       except: return raw.decode("utf-8", errors="replace")
   ```

2. **写回（重要pitfall！）**：
   - `write_file` 工具默认以 UTF-8 写入 → **会破坏 GBK 编码文件**！
   - 必须用二进制模式 + 指定编码写入：
     ```python
     def write_gbk(path, content):
         with open(path, "wb") as f:
             f.write(content.encode("gbk"))
     ```
   - 原始文件在 `金数源码/金数源码/` 中备份（原始编码不受影响），修改的是副本目录

3. **正则提取**：`用途[:：]\\s*(.*)`、`生成接口表\\s+(\\S+)`、`PROCEDURE\\s+(\\w+)`

4. **构建缩写映射字典**（从文件名推断）：
   ```python
   BIZ_MAP = {
       "101": "存款类 — 金融机构负债",
       "102": "客户信息类",
       "201": "贷款类",
       "202": "存款类",
       "203": "债券/投资类",
       "205": "票据类",
   }
   ```
   - 两种映射：裸缩写（CLDWDK→存量对公贷款信息）和 _HIS 后缀变体（自动去除 _HIS 后缀再查）
   - 数字编号前缀（如 201_）直接对应业务域

### 阶段三：域划分与并行调度

1. **按业务域/编号体系分组**（如数据库存储过程通常有编号：101=机构, 102=客户, 201=贷款, 202=存款, 203=债券, 205=表外等）
2. **每组分配一个 delegate_task 子任务**（最多 3 个并行）：
   - 每个子任务 context 中明确列出所有文件路径、已知用途、输出表
   - 设置 `toolsets=["file","terminal"]`（仅需读写文件和少量 shell）
3. **子任务内的工作流**：
   - 用 `read_file` 读每个文件的前 60-100 行（头部注释）
   - 对关键 SQL（INSERT/SELECT）跟进读取
   - 用 `write_file` 写入实体 .md 文件

### 阶段四：实体文件结构

每个实体文件遵循以下结构：

```markdown
# 文件名

## 基本元信息
- 存储过程名/脚本名:
- 业务域:
- 输出接口表:

## 用途说明
从注释提取的用途描述

## 功能概述
- 解决什么问题
- 在什么场景下触发（日终/月终/季度末）
- 数据流向

## 依赖关系
表格形式列出依赖的表/视图及其用途

## 关键逻辑
分条目列出核心加工规则

## 修改历史
需求编号、上线日期、修改原因
```

## 注意事项（踩坑记录）

### 编码问题
- Oracle PRC 文件的注释是 GBK 编码，用 UTF-8 直接 open 会乱码
- 在 execute_code 中使用 `for enc in ['gbk', 'gb18030', 'utf-8']` 逐一尝试解码
- read_file 工具能自动处理编码，优先使用
- **写回编码**：更新 .prc 文件头部注释时，必须用原编码（GBK）写回，否则中文会乱码。用 `iconv -f UTF-8 -t GBK` 转换后再写入

### 大文件处理
- 对 1000+ 行的 PRC 文件，只需读前 60-80 行和关键 SQL 段
- 实体文件是**总结性文档**，不是完整源码
- 标记"该文件共 X 行，详细 SQL 逻辑见源码注释"

### 子任务限制
- delegate_task 的 leaf agent 只有 terminal、read_file、write_file、search_files
- 无法使用 execute_code 做批量处理，必须逐文件 read_file
- 每个子任务的 context 要自包含——传入文件路径和已知元信息
- 子任务内 terminal 的 mkdir 可能因路径不存在失败，优先用 write_file（自动创建目录）

### 目录层级确认（高频踩坑）
- **创建分析/整理用的新目录前，必须用 `find` 确认目录结构全貌**
- 当项目中有同名嵌套目录时（如`金数源码/金数源码/`），极易混淆上下级关系
- "将A下的内容复制到B"——明确A是指子目录还是根目录。用绝对路径验证
- **先展示结构确认，再动手**：用 `clarify` 或书面展示让用户确认位置
- 不要因"看起来明显"就跳过确认步骤

### 缩写翻译
- 银行/金融系统中文件名缩写密集（CL=存量 CLear, FS=发生额 FaSheng, HDA=核对 HeDui）
- 需要在主任务提前翻译好，作为 context 传给子任务
- _HIS 后缀的文件是历史镜像版本（取历史快照数据），逻辑与主版相同

### Markdown 链接编码问题（高频踩坑）
- 文件名包含括号 `()` 时（如 `单位存款连续性调整(村镇).md`），在 markdown 链接语法 `[text](path)` 中 **括号会被解析器截断**
- 修复方案：生成链接时对路径中的 `(` 和 `)` 进行 URL 编码：
  ```python
  path.replace("(", "%28").replace(")", "%29")
  ```
- 其他需要编码的特殊字符：空格（`%20`）、中文（自动编码）
- 验证手段：生成后遍历所有 `[text](path)` 链接，用 `os.path.exists()` 检查

### SMTMODS 表引用提取（大小写问题）
- SQL 代码中对表名的引用可能大小写混用（`smtmods.l_cust_all`、`SMTMODS.L_CUST_ALL`）
- 提取时必须使用 `re.IGNORECASE` 并统一转为大写，否则同表名会分裂为多个条目
  ```python
  # ❌ 错误：只能匹配大写
  for m in re.finditer(r'SMTMODS\\.(\\w+)', text):
  
  # ✅ 正确：不区分大小写，统一大写
  for m in re.finditer(r'SMTMODS\\.(\\w+)', text, re.IGNORECASE):
      tables.add(m.group(1).upper())
  ```

## 增强工作流：实体目录重组（从源码一对一 → 按报表聚合）

### 场景说明

项目初期，实体文件按源码文件**一对一**组织（`实体/加工层存储/xxx.md` 对应 `源码解析/加工层存储/xxx.prc`）。但当多个源码文件（加工层存储主程序 + 加工层特殊处理修正SQL + 应用层特殊处理汇总SQL）操作同一个**接口表（报表）**时，用户需要的是一个按报表聚合的实体文件，而不是分散的多个文件。

### 重组前确认

用 `clarify` 与用户确认聚合粒度，避免盲目重组：

| 粒度 | 说明 | 适用场景 |
|------|------|----------|
| **按接口表名** | 每个接口表（PBOCD_JS_xxx / JS_xxx）一个实体文件 | 大多数金融监管项目 |
| **按业务主题** | 贷款类、存款类、票据类等大类聚合 | 文档较少，按主题阅读 |
| **按报表输出途径** | 报送EAST的、报送PBOCD的 | 跨系统报送场景 |

### 重组流程

#### 第一步：建立接口表→源码文件映射

```python
# 扫描所有源码文件，提取 TRUNCATE/INSERT/MERGE INTO 的目标接口表
import re, json, os

DIRS = [
    {"key": "加工层存储", "src": "源码解析/加工层存储", "ext": ".prc"},
    {"key": "加工层特殊处理", "src": "源码解析/加工层特殊处理", "ext": ".sql"},
    {"key": "应用层特殊处理", "src": "源码解析/应用层特殊处理", "ext": ".sql"},
]

report_map = {}  # 接口表名 → {files: [...], all_smt_tables: set()}

for d in DIRS:
    for fname in os.listdir(d["src"]):
        if not fname.endswith(d["ext"]): continue
        content = open(os.path.join(d["src"], fname)).read()
        # 匹配三种输出表语法
        for m in re.finditer(
            r'(?:TRUNCATE\s+TABLE|INSERT\s+INTO|MERGE\s+INTO)\s+(?:\w+\.)?(PBOCD_[\w_]+|JS_[\w_]+|L_[\w]+)',
            content, re.I):
            tbl = m.group(1).upper()
            report_map.setdefault(tbl, {"files": [], "all_smt_tables": set()})
            report_map[tbl]["files"].append({"fname": fname, "dir": d["key"]})
```

**关键正则**：必须同时匹配 `TRUNCATE TABLE`、`INSERT INTO`、`MERGE INTO` 三种语法。只匹配前两种会遗漏 `MERGE INTO` 操作的表（加工层特殊处理和应用层特殊处理的常用语法）。

#### 第二步：过滤核心报表

去掉辅助表（`_TMP`、`_TEMP`、`_SQ`、`_MAPPING`、`_SPOP_BK`、日期后缀版本如 `_20251201`、日历后缀如 `_LOAN`）：

```python
def is_core_report(name):
    short = name.replace("PBOCD_DATACORE.", "").replace("PBOCD_", "").replace("JS_", "")
    if any(x in short for x in ["_TMP", "_TEMP", "_SQ", "_MAPPING", "_SPOP_BK"]): return False
    if re.search(r'_\d{8}$', short): return False  # 日期版本
    if short.endswith("_LOAN"): return False
    return True
```

#### 第三步：合并同源报表（别名归一化）

不同原始名前缀（`PBOCD_JS_201_CLDWDK` vs `JS_201_CLDWDK`）指向同一个核心报表：

```python
def normalize_name(n):
    n = n.replace("PBOCD_DATACORE.", "").replace("PBOCD_", "")
    if not n.startswith("JS_"): return f"JS_{n}"
    return n
```

用 `normalize_name` 作为字典 key 合并多个原始名的记录。

#### 第四步：构建实体文件内容（合并多源旧内容）

```python
def build_entity_content(primary_name, info):
    # 核心结构
    lines = []
    lines.append(f"# {cn_name}（{short_name}）")
    lines.append(f"> 接口表：`{primary_name}` · 业务域：{biz_tag}")
    
    # 报表说明 — 从主程序旧实体文件中提取用途说明
    # 涉及源码文件 — 按角色分类：
    #   ### 数据生成（加工层存储）
    #   ### 数据修正（加工层特殊处理）
    #   ### 数据引用（应用层特殊处理）
    # 每个文件列出文件名 + 角色 + 链接到源码解析
    # 引用的监管集市表 — 合并所有子文件的 SMTMODS 引用
    # 关键逻辑 — 从主程序旧实体文件中提取
    # 修改历史 — 合并所有子文件的历史记录（去重）
    # 双向链接 — 回首页 + 到源码解析主程序
```

**合并规则**：
- **报表说明/用途**：取主程序（加工层存储中生成该表的 .prc）的旧实体文件内容
- **关键逻辑**：同上，主程序内容为骨架
- **功能概述**：同上
- **修改历史**：合并所有子文件，去重
- **SMTMODS 表**：合并所有子文件的引用，去重

#### 第五步：删除旧实体文件 + 更新 index.md

```bash
rm -rf 实体/加工层存储 实体/加工层特殊处理 实体/应用层特殊处理
```

重新生成 index.md，所有 `实体/加工层存储/xxx.md` 链接改为 `实体/<中文名>_<接口表名>.md` 格式。

### 文件名安全化（高频踩坑）

实体文件名包含中文括号 `()` 时（如 `存量助学贷款(教育贴息)_xxx.md`），markdown 链接 `[text](path)` 中的括号会被解析器截断。**必须替换：**

```python
def safe_filename(s):
    """文件名安全化：括号替换为全角，斜杠替换为全角"""
    return s.replace("(", "（").replace(")", "）").replace("/", "／")
```

同理，链接路径生成时也要使用安全化后的中文名。

### JS_ 前缀一致性（高频踩坑）

接口表名标准化时，`short_name` 函数和实体文件名中的 `sn` 必须使用相同的策略——要么统一保留 `JS_` 前缀，要么统一去掉。不一致会导致 index.md 链接指向不存在的文件。

```python
# 必须一致！生成实体文件和 index.md 链接的 short_name 要用同一套逻辑
def short_name(t):
    n = t.replace("PBOCD_DATACORE.", "").replace("PBOCD_", "")
    if not n.startswith("JS_"): n = f"JS_{n}"
    return n  # 如 "JS_201_CLDWDK"
```

中文名映射查询链：
```
输入: "JS_201_CLDWDK"
→ 去掉 JS_ → "201_CLDWDK"
→ 去掉数字前缀 → "CLDWDK"  ← 查表
→ 返回 "存量单位贷款"
```

```python
def get_cn(short):
    candidates = [short]
    if short.startswith("JS_"): candidates.append(short[3:])
    for s in list(candidates):
        pure = re.sub(r'^\d+_', '', s)
        if pure != s: candidates.append(pure)
    for c in candidates:
        if c in CN_TABLE_MAP: return CN_TABLE_MAP[c]
    return short
```

### AGENTS.md 三层查询路由

重组完成后，**必须同步更新 AGENTS.md**，定义新的查询流程：

```markdown
第一层：index.md（一级路由）
  → 按业务域分组查报表 / 按源码文件反向索引查程序
  → 获取实体文件路径

第二层：实体文件（功能/概述层）
  → 角色分类：数据生成（加工层存储）/ 数据修正（加工层特殊处理）/ 数据引用（应用层特殊处理）
  → 获取报表说明、数据流转、引用的监管集市表

第三层：源码解析文件（字段级取数逻辑）
  → 用户追问字段细节时，查 SQL 代码中的具体字段映射
  → 结合参考资料/监管集市/下的表定义文档查字段中文名
```

删除 AGENTS.md 中所有引用旧实体路径（`实体/加工层存储/`）的示例，替换为新的路径格式。

## 增强工作流：基于原文文件的实体文档重建

### 场景说明

项目可能经历**三个阶段**的实体文档组织演变：

```
阶段一：一对一（源码→实体）
  实体/加工层存储/bsp_sp_js_201_cldwdk.md  ← 每个源码文件对应一个实体文件

阶段二：按接口表聚合（报表→源码）
  实体/存量单位贷款_JS_201_CLDWDK.md       ← 按接口表名聚合，汇总所有涉及该表的源码文件

阶段三：基于原文（监管规范→实体）
  实体/存量单位贷款信息_JS_201_CLDWDK.md   ← 以监管机构原文文件为基准重建
```

**阶段三的触发条件**：项目目录下出现 `参考资料/金融基础数据系统/` 或类似的监管规范原文目录，用户明确要求"以原文文件重新整理实体文件"。

### PDF补充：从规范文档提取缺失报表定义

#### 场景

当"不在原文中的报表"清单中的某些报表，在项目目录下存在《金融基础数据采集规范》等PDF文档时，可以从PDF中提取定义作为补充。

#### 工具与安装

```bash
sudo apt-get install -y poppler-utils
```

#### 提取策略

PDF通常为两栏布局（左栏接口表代码，右栏中文描述），纯文本提取有两种模式：

| 模式 | 特点 | 适用场景 |
|------|------|----------|
| `pdftotext -raw` | 按页流顺序提取，两栏文本交错 | 从混杂文本中提取每个报表的段落 |
| `pdftotext -layout` | 保持版面位置，两栏并行排列 | 查看页面结构，理解上下文 |

推荐用 `-raw` 模式 + 正则提取：

```bash
pdftotext -raw V2.1.pdf /tmp/pdf_raw.txt
```

#### 正则提取每个报表描述

```python
import re
with open("/tmp/pdf_raw.txt", "r", encoding="utf-8") as f:
    text = f.read()

# 模式1：JS_xxx独占一行（大多数情况）
pattern1 = re.compile(r'JS_xxx\n(.+?)(?=\nJS_\w+\n)', re.DOTALL)

# 模式2：JS_xxx 在同一行后跟中文（少数情况）
pattern2 = re.compile(r'JS_xxx\s+(.+?)(?=\nJS_\w+)', re.DOTALL)
```

#### 生成的补充原文文件结构

```markdown
# 中文名-原文（PDF补充）

## 来源信息
| 来源文档 | 金融基础数据采集规范 V2.1（PDF提取） |
| 表代码 | JS_xxx |
| 整理日期 | YYYY-MM-DD |

## 表级业务说明（报送范围）
（从PDF提取的描述文本，需清理两栏混入的杂音）

## 字段清单原文
> 字段清单见PDF原文（因表格提取限制，字段级定义请直接查阅PDF文档）
```

#### 注意事项

1. **文本杂音清理**：raw模式提取后，末尾可能混入右栏文本（如"存款同业存放"），需人工校对
2. **字段清单缺失**：PDF表格中的字段清单难以用pdftotext提取，在文件中指引到PDF原文
3. **文件名规范**：与原始原文文件格式保持一致 `YYYY-MM-DD-JS_xxx_中文名-原文.md`
4. **来源标记**：实体文件中标注"📄 PDF补充"，区别于原始原文文件
5. **字段级完整提取**：当用户要求"通读PDF全部内容"时，需用章节定位+正则提取字段表格（见 `references/金融基础数据系统原文实体重建.md` 中"PDF补充：字段级表格提取（完整版）"章节）

#### 已知PDF补充成果参考

从"金融基础数据采集规范V2.1.pdf"（184页，44个接口表定义）中成功提取了4个缺失报表：
- JS_102_GRKHXX（个人客户基础信息）
- JS_102_TYKHXX（同业客户基础信息）
- JS_201_DBHTXX（担保合同信息）
- JS_202_CLGRCK（存量个人存款信息）

### 实体文件≠原文复制（用户明确纠正）

**核心原则**：实体文件是对原文的**总结**，加上从源码中提取的**关键逻辑**和**特殊处理规则**，而不是原文的复制品。

用户明确指出：*"实体文件不能跟原文一模一样，只是对原文的总结，以及源码内容的整理，外加源码的特殊处理逻辑"*

#### 最终实体文件结构

```
# 报表中文名（接口表名）

> **来源**：[原文文件链接]

## 报表说明（精简总结，1-2句话，非整段复制）
→ 从原文"官方报送范围"中取第一句话即可

## 业务分类
| 接口表 | JS_xxx |
| 中文名 | xxx |
| 章节 | 3.x.x.x |

## 关键逻辑（从源码提取的核心业务规则）
- **功能**：从源码头部注释提取的用途说明
- **映射**：从SQL中提取的CASE WHEN/字段映射规则
  → "条件... → 结果" 格式
- **变更**：修改历史中的关键原因

## 特殊处理规则（从加工层特殊处理SQL提取）
**文件名.sql**：
- **规则**：SQL注释中的规则描述
- **操作**：MERGE INTO / UPDATE 目标表

## 涉及源码文件
- 数据生成：[prc文件链接]（加工层存储）
- 数据修正：[sql文件链接]（加工层特殊处理）
- 数据引用：[sql文件链接]（应用层特殊处理）

## 引用的监管集市表
| 表名 | 中文名 |

## 字段清单（指引到原文，不复制字段表）
→ "完整字段清单及填报说明请查看原文" + 原文链接
```

#### 关键逻辑提取技术

从 `.prc` 源码文件中提取关键逻辑：

```python
def extract_key_logic_from_prc(prc_path):
    content = read_gbk(prc_path)
    logics = []
    
    # 1. 功能描述：从头部注释提取"用途"
    m = re.search(r'用途[：:]\s*(.*?)(?:\n)', content)
    if m: logics.append(f"**功能**：{m.group(1).strip()}")
    
    # 2. 关键变更：从修改历史提取修改原因
    changes = re.findall(r'修改原因[：:](.+?)(?:\n)', content)
    for c in changes[:3]:
        logics.append(f"**变更**：{c.strip()}")
    
    # 3. 映射规则：从CASE WHEN中提取关键映射
    case_map = re.findall(r'CASE\s+WHEN\s+([^)]+?)\s+THEN\s+["\']?(\w+)["\']?', content)
    seen = set()
    for cond, result in case_map:
        key = f"{cond[:30]} → {result}"
        if key not in seen and len(seen) < 5:
            seen.add(key)
            logics.append(f"**映射**：{cond[:40]}... → {result}")
    
    return logics[:8]
```

### 实体文件是总结不是复制品（用户核心纠正）

- ❌ **错误做法**：将原文的"数据范围/时间范围/报送粒度/纳入排除口径"整段复制到实体文件中
- ✅ **正确做法**：实体文件只包含三部分——原文精简总结（1-2句）+ 源码关键逻辑（CASE WHEN映射/功能描述/变更）+ 特殊处理规则（从SQL提取的原始注释），**字段清单仅指引到原文路径，不复制字段表全文**
- 用户原话：*"实体文件不能跟原文一模一样，只是对原文的总结，以及源码内容的整理，外加源码的特殊处理逻辑"*

### 特殊处理规则提取：跳过头部注释

SQL文件头部注释（如 `---分隔符` 之间的内容）是自动生成的，**不应包含**在实体文件的特殊处理规则中。只提取SQL文件中的**原始注释**：

```python
def extract_special_logic(sql_path):
    content = read_file(sql_path)
    
    lines = content.split('\n')
    in_header = False
    for line in lines:
        if line.strip().startswith('---') and len(line.strip()) > 10:
            in_header = not in_header  # 跳过分隔符之间的内容
            continue
        if in_header: continue
        # 只取第一条原始注释
        if line.strip().startswith('--') and '规则' in line:
            logics.append(f"**规则**：{line.strip().lstrip('-').strip()}")
            break
        elif line.strip().startswith('--') and len(line.strip()) > 10:
            logics.append(f"**处理**：{line.strip().lstrip('-').strip()}")
            break
```

#### 阶段三的关键差异

| 维度 | 阶段一/二 | 阶段三 |
|------|-----------|--------|
| 数据来源 | 源码文件注释 + SQL逻辑 | 监管机构原文文件（规范文档） |
| 内容重点 | 功能概述、关键逻辑、修改历史 | 原文总结 + 源码关键逻辑 + 特殊处理规则 |
| 报表说明 | 从源码注释提取 | 从原文提取第一句（精简总结） |
| 范围控制 | 按源码文件有无覆盖 | 按原文文件全量覆盖 |
| 缺失处理 | 无 | 需标记"有原文无实现"和"有实现无原文" |
| **关键逻辑** | 手动编写 | 从SQL代码自动提取（CASE WHEN/WHERE条件） |
| **特殊处理规则** | 无 | 从加工层特殊处理SQL提取原始注释 |

### 原文文件命名规范

监管原文文件常见命名格式：

```
YYYY-MM-DD-JS_201_CLDWDK_存量单位贷款信息-原文.md
YYYY-MM-DD-五篇大文章-3.5存量普惠贷款信息-原文.md
```

提取接口表名和中文名的正则：

```python
def parse_original_filename(fname):
    name_part = fname.replace("-原文.md", "")
    name_part = re.sub(r'^\d{4}-\d{2}-\d{2}-', '', name_part)
    m = re.search(r'(JS_[A-Z0-9_]+)', name_part)
    tbl = m.group(1).rstrip("_") if m else None
    # 五篇大文章需硬编码映射
    wupian_map = {"3.1存量科技贷款": "JS_201_HDACLKJDK", ...}
    if not tbl:
        for key, tbl_name in wupian_map.items():
            if key in name_part: tbl = tbl_name; break
    cn = name_part
    if tbl: cn = cn.replace(tbl, "").strip("_ -")
    return tbl, cn
```

### 实体文件重建流程

#### 第一步：对账（原文 vs 源码）

建立完整对照表，识别三类关系。

#### 第二步：从原文提取关键内容

正则提取标准化章节：报送范围、数据范围、时间范围、报送粒度、纳入排除口径。

#### 第三步：关联并分类源码文件

三段式角色分类：**数据生成**（加工层存储 .prc）、**数据修正**（加工层特殊处理 .sql）、**数据引用**（应用层特殊处理 .sql）。

#### 第四步：构建实体文件

结构（⚠️ 非原文复制，而是总结+源码逻辑）：

```
报表说明（精简总结，1-2句） → 非整段复制
业务分类（接口表代码、中文名、章节）
关键逻辑（从源码提取：功能描述 + CASE WHEN映射 + 关键变更）
特殊处理规则（从特殊处理SQL提取原始注释）
涉及源码文件（三段式：生成/修正/引用）
引用的监管集市表
字段清单（指向原文，不复制字段表）
```

⚠️ **不要**将原文的"数据范围/时间范围/报送粒度/纳入排除口径"整段复制到实体文件中——用户明确纠正过"实体文件不能跟原文一模一样"。

#### 第五步：更新路由索引和 AGENTS.md

1. 基于实体目录实际文件列表重写 index.md
2. AGENTS.md 实体文件说明改为"基于金融基础数据系统原文"
3. 补充"不在原文中的报表"表格

### 缺失处理规范

- **有原文无实现码**：实体文件中标注"（暂未找到对应源码）"
- **有实现无原文**：AGENTS.md 末尾建表格，查询时注明"无原文参考"

### 陷阱清单

1. **文件名安全化**：原文中文名中 `(教育贴息)` 的括号会被 markdown 解析器截断，必须替换为全角 `（）`
2. **五篇大文章无JS_表名**：需要硬编码章节号→接口表名的映射
3. **解析正则限定字符集**：`r'(JS_[A-Z0-9_]+)'` 而非 `\w+`，避免匹配到中文
4. **角色去重**：同一个文件可能出现在多个报表中，按 `(fname, dir)` 去重

## 增强工作流：监管集市表关联与双向同步

### 场景说明
当源码中引用 `SMTMODS.xxx` 等监管集市表，且项目目录下有对应的表定义文档时，需要对源码进行**交叉验证和同步更新**。

### 查询路径（固定顺序）
1. **先读表清单**：查找目录下的 `监管集市表清单.md`（索引文件），确认表是否存在
2. **从清单定位文件名**：清单列出序号、物理表名、中文名、字段数、文档链接
3. **读表定义文件**：提取关键元信息（中文名、主题、频率、字段数、关键字段说明）
4. **匹配到源码逻辑**：将表的中文名和字段说明映射到 SQL 的 INSERT/SELECT/JOIN 中

### 实体文件增强格式

在原有实体结构基础上，增加监管集市表关联信息：

```markdown
## 依赖关系（监管集市表）

| 表名 | 中文名 | 用途 |
|------|--------|------|
| SMTMODS.L_ACCT_LOAN | 贷款借据信息表 | 主数据源：提取贷款发放记录 |
| SMTMODS.L_CUST_C | 对公客户补充信息表 | 排除个体工商户 |
| ... | ... | ... |
```

关键原则：
- 每个引用的表**都必须配上中文名**（从监管集市表定义中查）
- 用途栏说明该表在存储过程中的具体作用（不写泛泛描述）
- 字段引用建议标注具体字段名（如 `DIGITAL_ECONOMY_INDUSTRY`）

### 双向同步流程

整理后的汇总信息需要同步两个位置：

```
源码解析/加工层存储/xxx.prc    ← 更新头部注释块（增强版）
实体/加工层存储/xxx.md          ← 更新实体文档（同步一致）
```

**更新 .prc 头部注释的规范格式**：

```sql
  ------------------------------------------------------------------------------------------------------
  -- 程序名
  -- BSP_SP_JS_201_XXX
  -- 业务域: xxx — xxx
  -- 用途: 生成接口表 PBOCD_JS_201_XXX，具体功能描述
  -- 输出接口表: PBOCD_JS_201_XXX
  -- 参数
  --    IS_DATE 输入变量，传入跑批日期
  --    OI_RETCODE 输出变量，标识执行过程是否异常
  -- 引用的监管集市表
  --    SMTMODS.L_xxx — xxx表（中文名 + 用途）
  --    ...
  -- 关键逻辑
  --    1. xxx
  --    2. xxx
  -- 修改历史
  --    2025-xx-xx（需求编号）原因，修改人，操作
  ------------------------------------------------------------------------------------------------------
```

**同步规则**：
1. 实体文档的内容必须与源码头部的注释一致（用途、逻辑、依赖关系）
2. 源码注释偏向"开发者视角"（参数、SQL逻辑细节）
3. 实体文档偏向"分析者视角"（业务背景、功能概述、依赖关系表格）
4. 差异检查清单：用途说明、依赖表、关键逻辑条目数

## 参考
- AGENTS.md 中的 Ingest 操作流程定义了"实体"文档规范
- AGENTS.md 禁止行为："不得将完整源码写入实体目录"
- `references/监管集市表关联工作流.md` — 监管集市表定义文件的查询步骤和依赖关系表格生成规范
- `references/金融系统缩写翻译.md` — 金融文件名缩写翻译字典（编号体系、业务类型缩写）
- `references/路由索引生成模式.md` — 双向交叉引用索引（by-report + by-file reverse index）的生成和工作原理
- `references/金融基础数据系统原文实体重建.md` — 53个原文文件（含4个PDF补充）的完整对账表、五篇大文章→接口表名映射字典、接口表中文名映射字典、PDF提取方法、不在原文和PDF中的5个报表清单及三层查询路由
- `templates/batch-enrich.py` — 批量增强源码注释 + 同步实体文档的完整脚本模板。调用前需先建好 table_map.json，按项目修改 DIRS 配置和编码工具函数即可复用

## 扩展工作流：生成路由索引

### 场景说明
批量源码分析完成后，项目会拥有三类文件：
- `源码解析/` — 增强注释后的源码文件（.prc / .sql）
- `实体/` — 每个文件的总结文档（.md）
- `参考资料/监管集市/` — 监管集市表定义文档（.md）

**路由索引**的作用是将这三者串联起来，生成一个**双向查询入口**，让用户可以从"表名→程序"和"程序→表"两个方向自由导航。

### 三层查询架构

```
用户提问
  │
  ▼
第一层：路由索引（index.md）
  │  从表名查到程序列表
  │  从程序名查到实体文件链接
  ▼
第二层：实体文件（功能/概述）
  │  获取用途说明、功能概述、依赖关系
  ▼
第三层：源码文件（字段级）
    用户追问字段取数逻辑时 → 查SQL代码中的具体字段映射
```

### 路由索引文件结构

一个完整的路由索引包含两个部分：

#### 第一部分：按程序索引
每个程序一条记录，包含基本信息 + 引用的监管集市表清单：

```markdown
### BSP_SP_JS_201_HDASZDKFS

| 属性 | 值 |
|------|-----|
| 业务域 | 贷款类 |
| 实体文件 | [xx.md](实体/加工层存储/xx.md) |
| 源码文件 | [xx.prc](源码解析/加工层存储/xx.prc) |
| 用途 | 生成接口表 PBOCD_JS_201_HDASZDKFS ... |

**引用的监管集市表：**

| 物理表名 | 中文名 |
|----------|--------|
| `L_ACCT_LOAN` | 贷款借据信息表 |
| `L_CUST_C` | 对公客户补充信息表 |
```

#### 第二部分：按表反向索引
每个监管集市表列出被哪些程序引用：

```markdown
### L_ACCT_LOAN — 贷款借据信息表

被 39 个程序引用：

- [BSP_SP_JS_201_HDASZDKFS](实体/加工层存储/xxx.md)（加工层存储）
- [BSP_SP_JS_205_CLPJRZ](实体/加工层存储/xxx.md)（加工层存储）
```

### 生成脚本要点

1. **数据源**：本次从源码文件中提取的 `(程序名, [表名列表])` 映射
2. **表名统一**：用 `re.IGNORECASE` + `.upper()` 将所有表名转大写，避免大小写分裂
3. **链接编码**：路径中的括号 `()` 需转为 `%28`/`%29` 否则 markdown 链接断裂
4. **反向索引构建**：用字典 `{表名: [(程序名, 目录, 实体路径), ...]}` 汇总
5. **验证**：生成后遍历所有 `[text](path)` 链接，用 `os.path.exists()` 逐一确认
